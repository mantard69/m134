

-----------------------------------------------
M134 Trouble Shooting
-----------------------------------------------
If M134 keeps prompting you for Cncs232.dll, 
or CCTrans.dll, you should try moving them 
into C:\WINDOWS\SYSTEM.

The dll's are for transparency fades and such.


If the time and kill counters look off balance
or in the wrong spot, copy the font files into
C:\WINDOWS\FONTS.


-Rydin
-----------------------------------------------